﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar)) return;
            else e.Handled = true;
        }

        public string slovo = "телефон";
        public int oshibka = 0;
        public int x = 20;
        public int y = 30;

        //Начальные настройки
        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Вводить только русские буквы!");
            textBox2.Text = "т";
            textBox3.Text = "е"; textBox5.Text = "е";
            textBox4.Text = "л";
            textBox6.Text = "ф";
            textBox7.Text = "о";
            textBox8.Text = "н";
            textBox2.Visible = false; textBox3.Visible = false; textBox4.Visible = false;
            textBox5.Visible = false; textBox6.Visible = false; textBox7.Visible = false; textBox8.Visible = false;
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            Graphics GRAFIC = this.CreateGraphics();

            if (oshibka > 10)
            {
                MessageBox.Show("Повешен...");
                GRAFIC.Clear(Color.White);
                textBox1.Text = "";
                textBox2.Visible = false; textBox3.Visible = false; textBox4.Visible = false;
                textBox5.Visible = false; textBox6.Visible = false; textBox7.Visible = false; textBox8.Visible = false; 
            }

            if (e.KeyData == Keys.Enter && textBox1.Text != "")
            {
                Pen MyPe = new Pen(Color.DarkGray, 7);
                Pen MyPen = new Pen(Color.DarkGoldenrod, 7);
                Pen MyPenc = new Pen(Color.DarkRed, 7);
                if (label4.Text.IndexOf(textBox1.Text) == -1)
                {
                    label4.Text.Trim();
                    switch (textBox1.Text)
                    {
                        case "Т": case "т": textBox2.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                        case "Е": case "е": textBox3.Visible = true; textBox5.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                        case "Л": case "л": textBox4.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                        case "Ф": case "ф": textBox6.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                        case "О": case "о": textBox7.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                        case "Н": case "н": textBox8.Visible = true; label4.Text += textBox1.Text + " "; textBox1.Text = null; break;
                        default:
                            label4.Text += textBox1.Text + " "; textBox1.Text = null; oshibka++;
                            switch (oshibka)
                            {
                                case 1: GRAFIC.DrawLine(MyPe, x+150, y + 10, x + 150, y + 250); break;
                                case 2: GRAFIC.DrawLine(MyPe, x+140, y + 250, x + 240, y + 250); break;
                                case 3: GRAFIC.DrawLine(MyPe, x+140, y + 10, x + 280, y + 10); break;
                                case 4: GRAFIC.DrawLine(MyPe, x+150, y + 40, x + 190, y + 10); break;
                                case 5: GRAFIC.DrawLine(MyPen, x+260, y + 10, x + 260, y + 40); break;
                                case 6: GRAFIC.DrawEllipse(MyPenc, x+240, y + 40, 40, 40); break;
                                case 7: GRAFIC.DrawEllipse(MyPenc, x+230, y + 80, 60, 80); break;
                                case 8: GRAFIC.DrawLine(MyPenc, x+250, y + 80, x + 200, y + 120); break;
                                case 9: GRAFIC.DrawLine(MyPenc, x+270, y + 80, x + 320, y + 120); break;
                                case 10: GRAFIC.DrawLine(MyPenc, x+245, y + 155, x + 220, y + 220); break;
                                case 11: GRAFIC.DrawLine(MyPenc, x+275, y + 155, x + 300, y + 220); break;
                            }
                            break;
                    }
                }
                else MessageBox.Show("ПОВТОР БУКВЫ! ВВЕДИТЕ ДРУГУЮ!");
            }

            if (textBox2.Visible && textBox3.Visible && textBox4.Visible && textBox5.Visible && textBox6.Visible && textBox7.Visible && textBox8.Visible)
            {
                MessageBox.Show("Победа!");
                textBox2.Visible = false; textBox3.Visible = false; textBox4.Visible = false;
                textBox5.Visible = false; textBox6.Visible = false; textBox7.Visible = false; textBox8.Visible = false;
                oshibka = 0;
                GRAFIC.Clear(Color.White);
                label4.Text = null;
            }
        }
    }
}